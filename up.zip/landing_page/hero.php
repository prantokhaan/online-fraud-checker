<section class="hero">
    <div class="container">
        <div class="heroContainer">
            <div class="hero-content">
            <h1>Grab the Real Customers</h1>
            <p>Get the information about a customer. Determine his online shopping conditions.</p>
            <a href="#" class="btn">Get Started</a>
        </div>
        <div class="hero-image">
            <img src="images/hero.png" alt="Hero Image">
        </div>
        </div>
    </div>
</section>
