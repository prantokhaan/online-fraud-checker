<nav>
    <div class="navbar-container">
        <div class="logo">
            <a href="../index.php" class="logo-link">O <span>F</span> C</a>
        </div>
        <ul class="nav-links">
            <li><a href="../index.php">Home</a></li>
            <li><a href="../about.php">About</a></li>
            <li><a href="../contact.php">Contact</a></li>
        </ul>
        <div class="auth-buttons" id="auth-buttons">
    <a href="../profile/profile.php" id="profile-link" class="me-5"><i class="fas fa-user"> <span></span></i></a>
    <a href="#" id="logout-link"><i class="fas fa-sign-out-alt"><span>LogOut</span></i></a>
    <a href="../auth/login.php" id="login-link">Login</a>
    <a href="../auth/register.php" id="register-link">Register</a>
</div>

    </div>
</nav>
