<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="../css/change_password.css">
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="icon" href="../images/favicon.png">
</head>
<body>
    <!-- Include the sidebar using PHP -->
    <?php include '../shared/sidebar.php'; ?>

    <?php if (isset($_SESSION['password_change_success'])): ?>
        <div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="successModalLabel">Password Changed</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Your password has been changed successfully.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $('#successModal').modal('show');
        </script>
    <?php endif; ?>

    <?php if (isset($_SESSION['password_change_error'])): ?>
        <div class="modal fade" id="errorModal" tabindex="-1" role="dialog" aria-labelledby="errorModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="errorModalLabel">Error</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php echo $_SESSION['password_change_error']; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $('#errorModal').modal('show');
        </script>
    <?php endif; ?>
        <?php if(isset($_GET['error']) && $_GET['error'] == 'incorrect_password') {
            echo "<div class='alert alert-danger'>Incorrect old password.</div>";
        }else if(isset($_GET['error']) && $_GET['error'] == 'username_not_found'){
            echo "<div class='alert alert-danger'>Username not found. Please try again.</div>";
        }else if(isset($_GET['error']) && $_GET['error'] == 'password_mismatch'){
            echo "<div class='alert alert-danger'>Passwords do not match.</div>";
        }
        
        ?>
    <!-- Change Password Form -->
    <div class="main-content">
        <div class="change-password-container">
            <h2>Change Password</h2>
            <form action="process_change_password.php" method="post">
                <div class="form-group">
                    <label for="username">Your Email:</label>
                    <input type="text" id="username" name="username" class="form-control" placeholder="Enter your username" required>
                </div>
                <div class="form-group">
                    <label for="oldPassword">Old Password:</label>
                    <input type="password" id="oldPassword" name="oldPassword" class="form-control" placeholder="Enter your old password" required>
                </div>
                <div class="form-group">
                    <label for="newPassword">New Password:</label>
                    <input type="password" id="newPassword" name="newPassword" class="form-control" placeholder="Enter your new password" required>
                </div>
                <div class="form-group">
                    <label for="confirmNewPassword">Confirm New Password:</label>
                    <input type="password" id="confirmNewPassword" name="confirmNewPassword" class="form-control" placeholder="Confirm your new password" required>
                </div>
                <button type="submit" class="btn btn-primary">Change Password</button>
            </form>
        </div>
    </div>
    <!-- End of Change Password Form -->
</body>
</html>
