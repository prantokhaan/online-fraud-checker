<div class="admin_sidebar">
    <div class="logo">
        <a href="../index.php" class="logo-link">O <span>F</span> C</a>
    </div>
    <hr>
    <ul class="menu">
        <li><a href="../index.php">Home</a></li>
        <li><a href="../admin/all_user_list.php">All User List</a></li>
        <li><a href="../admin/all_subscriber.php">All Subscriber</a></li>
        <li><a href="../admin/all_complaints.php">All Complaints</a></li>
        <li><a href="../admin/pending_complaints.php">Pending Complaints</a></li>
        <li><a href="#">Logout</a></li>
    </ul>
</div>
