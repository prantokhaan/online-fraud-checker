<div class="admin_sidebar">
    <div class="logo">
        <a href="../index.php" class="logo-link">O <span>F</span> C</a>
    </div>
    <hr>
    <ul class="menu">
        <li><a href="../admin/all_user_list.php">All User List</a></li>
        <li><a href="../admin/all_complaints.php">All Complaints (Customer)</a></li>
        <li><a href="../admin/all_seller_complaints.php">All Complaints (Seller)</a></li>
        <li><a href="../admin/courier-register.php">Register a Courier</a></li>
        <li>
            <a href="../admin/all_courier_list.php">View Couriers</a>
        </li>
        <li>
            <a href="../admin/add_pricing.php">Add Package</a>
        </li>
        <li>
            <a href="../admin/view_packages.php">View Packages</a>
        </li>
        <li>
            <a href="../admin/deleted_user_list.php">Deleted Users</a>
        </li>
    </ul>
</div>
